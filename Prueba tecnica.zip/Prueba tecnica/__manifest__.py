{
    'name': 'Purchase Category Custom',  # Nombre del módulo
    'version': '1.0',  # Versión inicial
    'category': 'Purchases',  # Categoría para su clasificación en Odoo
    'depends': ['purchase'],  # Este módulo extiende funcionalidades del módulo de compras
    'data': [  # Archivos de datos cargados al instalar el módulo
        'security/groups.xml',  # Define el grupo "Categorizar compra"
        'security/ir.model.access.csv',  # Permisos de acceso a modelos
        'security/record_rules.xml',  # Reglas de acceso por usuario
        'views/purchase_category_views.xml',  # Vistas para gestionar las categorías
        'views/purchase_order_views.xml',  # Vista extendida de órdenes de compra
    ],
    'installable': True,  # Permite instalar el módulo desde el backend
}
