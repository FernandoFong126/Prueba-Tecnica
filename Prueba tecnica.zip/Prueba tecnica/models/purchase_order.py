from odoo import models, fields, api

class PurchaseOrder(models.Model):
    _inherit = 'purchase.order'  # Extendemos el modelo estándar de orden de compra

    purchase_category_id = fields.Many2one(
        'purchase.category',
        string='Categoría de Compra',
        readonly=True,  # Por defecto no editable
        states={'purchase': [('readonly', False)]}  # Editable solo cuando la orden está en estado 'purchase'
    )
class ResUsers(models.Model):
    _inherit = 'res.users'  # Extendemos el modelo de usuarios

    purchase_category_ids = fields.Many2many(
        'purchase.category',
        string='Categorías de Compra Asignadas'  # Categorías a las que el usuario tiene acceso
    )
