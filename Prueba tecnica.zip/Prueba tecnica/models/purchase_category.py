from odoo import models, fields

class PurchaseCategory(models.Model):
    _name = 'purchase.category'  # Nombre técnico del modelo
    _description = 'Categoría de Compra'  # Descripción mostrada en la interfaz

    name = fields.Char(string='Nombre', required=True)  # Campo obligatorio para identificar la categoría
    description = fields.Text(string='Descripción')  # Campo opcional para más detalles
