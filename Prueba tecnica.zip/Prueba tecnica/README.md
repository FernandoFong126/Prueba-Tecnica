# Módulo Odoo - Purchase Category Custom

Este módulo extiende el modelo de órdenes de compra (`purchase.order`) en Odoo para incluir una categorización adicional, con controles de visibilidad y permisos según usuario.

## Funcionalidades principales

1. Categoría de compra  
   Nuevo campo en las órdenes de compra para asignar una categoría (modelo `purchase.category`).

2. Control por estado  
   El campo solo es visible cuando la orden está en estado `purchase`.

3. Permisos por grupo  
   Solo los usuarios del grupo Categorizar compra pueden editar la categoría.

4. Asignación de categorías por usuario  
   Los usuarios tienen asignadas categorías específicas mediante un campo Many2many.

5. Filtrado automático  
   Cada usuario solo puede ver las órdenes con categorías que tiene asignadas.

## Archivos incluidos

```
purchase_category_custom/
├── __manifest__.py
├── models/
│   ├── purchase_order.py
│   └── purchase_category.py
├── views/
│   ├── purchase_order_views.xml
│   └── purchase_category_views.xml
├── security/
│   ├── ir.model.access.csv
│   ├── groups.xml
│   └── record_rules.xml
```

## Instalación

1. Copia la carpeta `purchase_category_custom` dentro del directorio de addons de tu instalación de Odoo.

2. Desde el backend de Odoo:
   - Activa el modo desarrollador.
   - Ve a Apps y haz clic en Actualizar lista de aplicaciones.
   - Busca e instala Purchase Category Custom.

## Cómo probarlo

1. Ve al módulo de Compras > Categorías de Compra y crea algunas categorías.

2. Edita un usuario (Configuración > Usuarios) y asígnale categorías en el campo Categorías de Compra Asignadas.

3. Agrega el grupo Categorizar compra al usuario para que pueda editar el campo en las órdenes.

4. Crea o edita una orden de compra:
   - Cambia el estado a Compra Confirmada.
   - Verifica que puedas ver y editar la categoría según tus permisos.
   - Asegúrate de que solo veas órdenes con categorías asignadas.

## Desinstalación limpia

- El módulo no sobrescribe ni elimina datos nativos de Odoo.
- Puedes desinstalarlo desde Apps sin comprometer el sistema.

## Requisitos

- Compatible con Odoo versión 15, 16 o 17.
- Requiere módulo base de purchase.